package com.proyectofinal.ico.proyecto_final;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
